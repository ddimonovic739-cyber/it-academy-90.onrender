# IT Academy 90 MAX — Render Edition

Адаптивная Flask-платформа для iPhone и ПК: 90-дневная программа, SQL Lab, упражнения, заметки по дням, проекты, XP, достижения и статистика. Для общего аккаунта между устройствами используй одну внешнюю PostgreSQL через `DATABASE_URL`.

## Рекомендуемая учебная бесплатная архитектура

- Render Free Web Service — запускает сайт, но засыпает после 15 минут без запросов.
- Neon PostgreSQL Free — хранит прогресс; compute масштабируется до нуля, но данные остаются в базе в пределах текущих условий/лимитов.
- GitHub — хранит исходный код и запускает автодеплой после commit.

Render Free PostgreSQL истекает через 30 дней, поэтому для учебного проекта не используй её, если нужно долго хранить прогресс бесплатно. Ограничения бесплатных сервисов могут меняться — проверяй актуальные тарифы.

## Быстрый запуск локально

Python 3.11+:

```bash
pip install -r requirements.txt
python app.py
```

Открой `http://127.0.0.1:5000`. Без `DATABASE_URL` используется SQLite только для локальной разработки.

## Деплой

Прочитай `DEPLOY_GUIDE_RENDER_RU.md`. В архиве есть `render.yaml` для Render Blueprint:

- Build: `pip install -r requirements.txt`
- Start: `gunicorn app:app --bind 0.0.0.0:$PORT`
- Health check: `/healthz`
- Environment: `DATABASE_URL`, `SECRET_KEY`, `COOKIE_SECURE=1`, `RENDER_REQUIRE_DATABASE=1`

Приложение специально не запускается на локальном SQLite в Render, если задан `RENDER_REQUIRE_DATABASE=1` и забыта `DATABASE_URL`: это защищает от ложного ощущения, что прогресс надёжно сохраняется.

## Проверки

```bash
pip install -r requirements-dev.txt
pytest -q
```

Также проверь `https://<твой-url>/healthz` — ожидание: `status=ok`, `database=postgresql`. Не делись `DATABASE_URL` или `SECRET_KEY`.

## Ограничения

Это учебная платформа, а не сервис с SLA или внешним аудитом безопасности. Квоты Render/Neon и требования бесплатных планов могут изменяться. Экспортируй прогресс и не храни секреты в GitHub.
