(() => {
  const root = document.documentElement;
  const storedTheme = localStorage.getItem('it-academy-theme');
  if (storedTheme === 'light' || storedTheme === 'dark') root.dataset.theme = storedTheme;
  const themeButton = document.querySelector('.theme-toggle');
  const updateThemeButton = () => {
    if (!themeButton) return;
    themeButton.textContent = root.dataset.theme === 'light' ? '☾' : '☀';
    themeButton.title = root.dataset.theme === 'light' ? 'Включить тёмную тему' : 'Включить светлую тему';
  };
  updateThemeButton();
  themeButton?.addEventListener('click', () => {
    root.dataset.theme = root.dataset.theme === 'light' ? 'dark' : 'light';
    localStorage.setItem('it-academy-theme', root.dataset.theme);
    updateThemeButton();
  });

  document.querySelectorAll('.flash-close').forEach((button) => {
    button.addEventListener('click', () => button.closest('.flash')?.remove());
  });

  // Do not cache authenticated HTML or API responses. Only static app-shell assets are cached.
  if ('serviceWorker' in navigator && location.protocol === 'https:') {
    window.addEventListener('load', () => navigator.serviceWorker.register('/service-worker.js').catch(() => {}));
  }

  document.querySelectorAll('[data-confirm]').forEach((el) => {
    el.addEventListener('click', (event) => {
      if (!window.confirm(el.dataset.confirm)) event.preventDefault();
    });
  });
})();
