"""Practice question bank and safe, isolated SQLite SQL lab."""
import sqlite3
import time
from decimal import Decimal

TASKS = [
    # SQL
    dict(id="sql-01", category="SQL", level="Начальный", difficulty="easy", title="SELECT", prompt="Какая команда выбирает данные из таблицы?", reference="SELECT", hint="Команда начинается с S.", rule="any", accepted=["select"]),
    dict(id="sql-02", category="SQL", level="Начальный", difficulty="easy", title="WHERE", prompt="Как называется условие фильтрации строк в SQL?", reference="WHERE", hint="Обычно идёт после FROM.", rule="any", accepted=["where"]),
    dict(id="sql-03", category="SQL", level="Начальный", difficulty="easy", title="Сортировка", prompt="Как сортировать цены от дорогих к дешёвым? Назови направление сортировки.", reference="ORDER BY price DESC", hint="DESC означает descending.", rule="all", accepted=["desc"]),
    dict(id="sql-04", category="SQL", level="Начальный", difficulty="easy", title="NULL", prompt="Как проверить, что значение отсутствует?", reference="IS NULL", hint="Сравнение = NULL не подходит.", rule="contains", accepted=["is null"]),
    dict(id="sql-05", category="SQL", level="Средний", difficulty="medium", title="LEFT JOIN", prompt="Какой JOIN сохраняет все строки левой таблицы, даже без совпадения?", reference="LEFT JOIN", hint="Название начинается с LEFT.", rule="contains", accepted=["left join"]),
    dict(id="sql-06", category="SQL", level="Средний", difficulty="medium", title="Группировка", prompt="Какая конструкция собирает строки в группы для COUNT/SUM?", reference="GROUP BY", hint="Два слова, второе — BY.", rule="contains", accepted=["group by"]),
    dict(id="sql-07", category="SQL", level="Средний", difficulty="medium", title="HAVING", prompt="Что используют для фильтрации групп после GROUP BY?", reference="HAVING", hint="WHERE фильтрует строки до группировки.", rule="contains", accepted=["having"]),
    dict(id="sql-08", category="SQL", level="Средний", difficulty="medium", title="Среднее", prompt="Как называется SQL-агрегат для среднего значения?", reference="AVG()", hint="Три буквы.", rule="contains", accepted=["avg"]),
    dict(id="sql-09", category="SQL", level="Средний", difficulty="medium", title="CTE", prompt="Какое ключевое слово обычно начинает CTE?", reference="WITH", hint="WITH named_query AS (...)", rule="exact_any", accepted=["with"]),
    dict(id="sql-10", category="SQL", level="Продвинутый", difficulty="hard", title="Оконное ранжирование", prompt="Какой шаблон нужен, чтобы ранжировать значения внутри каждой группы?", reference="RANK() OVER (PARTITION BY ... ORDER BY ...)", hint="В ответе должны быть RANK, OVER и PARTITION BY.", rule="all", accepted=["rank", "over", "partition by"]),
    dict(id="sql-11", category="SQL", level="Продвинутый", difficulty="hard", title="SQL-инъекция", prompt="Как защититься от SQL-инъекций при пользовательском вводе?", reference="Использовать параметризованные запросы / prepared statements.", hint="Не склеивать SQL из строк.", rule="any", accepted=["параметриз", "prepared statement", "параметр", "sql-инъекц"]),
    dict(id="sql-12", category="SQL", level="Средний", difficulty="medium", title="Внешний ключ", prompt="Как называется ограничение, связывающее запись с ключом другой таблицы?", reference="FOREIGN KEY", hint="Дословно — внешний ключ.", rule="any", accepted=["foreign key", "внешний ключ"]),
    # Python
    dict(id="py-01", category="Python", level="Начальный", difficulty="easy", title="Сумма списка", prompt="Что вернёт sum([1, 2, 3])? Введи число.", reference="6", hint="1 + 2 + 3.", rule="exact_any", accepted=["6"]),
    dict(id="py-02", category="Python", level="Начальный", difficulty="easy", title="Словарь", prompt="Какой встроенный тип хранит пары ключ-значение?", reference="dict", hint="В фигурных скобках часто записывают словарь.", rule="any", accepted=["dict", "словар"]),
    dict(id="py-03", category="Python", level="Начальный", difficulty="easy", title="Функция", prompt="Какое ключевое слово объявляет функцию Python?", reference="def", hint="def calculate(...):", rule="exact_any", accepted=["def"]),
    dict(id="py-04", category="Python", level="Средний", difficulty="medium", title="Инициализация объекта", prompt="Как называется специальный метод инициализации экземпляра класса?", reference="__init__", hint="Два подчёркивания с обеих сторон.", rule="contains", accepted=["__init__"]),
    dict(id="py-05", category="Python", level="Средний", difficulty="medium", title="Исключения", prompt="Какое ключевое слово начинает обработчик исключения?", reference="except", hint="try ... затем ...", rule="exact_any", accepted=["except"]),
    dict(id="py-06", category="Python", level="Средний", difficulty="medium", title="Контекстный менеджер", prompt="Какое ключевое слово используют для безопасной работы с файлом через контекстный менеджер?", reference="with", hint="with open(...) as f:", rule="exact_any", accepted=["with"]),
    dict(id="py-07", category="Python", level="Средний", difficulty="medium", title="Зависимости", prompt="В какой стандартный файл часто записывают зависимости Python-проекта?", reference="requirements.txt", hint="pip install -r ...", rule="contains", accepted=["requirements.txt"]),
    dict(id="py-08", category="Python", level="Средний", difficulty="medium", title="Тестирование", prompt="Назови один популярный Python-фреймворк для тестирования.", reference="pytest или unittest", hint="Один вариант: pytest.", rule="any", accepted=["pytest", "unittest"]),
    dict(id="py-09", category="Python", level="Средний", difficulty="medium", title="REST-клиент", prompt="Какая популярная библиотека позволяет делать HTTP-запросы из Python?", reference="requests", hint="Название во множественном числе.", rule="contains", accepted=["requests", "httpx"]),
    dict(id="py-10", category="Python", level="Продвинутый", difficulty="hard", title="Изменяемые значения по умолчанию", prompt="Почему список как значение аргумента по умолчанию может быть опасен?", reference="Он создаётся один раз и сохраняет изменения между вызовами.", hint="Объект переиспользуется между вызовами.", rule="all", accepted=["один раз", "между вызов",]),
    # API / systems analysis
    dict(id="api-01", category="API и HTTP", level="Начальный", difficulty="easy", title="Получение ресурса", prompt="Какой HTTP-метод обычно используют для чтения ресурса?", reference="GET", hint="GET /api/games", rule="exact_any", accepted=["get"]),
    dict(id="api-02", category="API и HTTP", level="Начальный", difficulty="easy", title="Создание ресурса", prompt="Какой HTTP-метод обычно используют для создания ресурса?", reference="POST", hint="POST /api/games", rule="exact_any", accepted=["post"]),
    dict(id="api-03", category="API и HTTP", level="Начальный", difficulty="easy", title="Успешный запрос", prompt="Какой код HTTP означает OK?", reference="200", hint="Три цифры.", rule="exact_any", accepted=["200"]),
    dict(id="api-04", category="API и HTTP", level="Средний", difficulty="medium", title="Не найдено", prompt="Какой HTTP-код означает Not Found?", reference="404", hint="Ресурс не найден.", rule="exact_any", accepted=["404"]),
    dict(id="sys-01", category="Системный анализ", level="Средний", difficulty="medium", title="Критерии приёмки", prompt="Как называется проверяемое условие, по которому решают, что user story выполнена?", reference="Acceptance criteria / критерий приёмки", hint="На английском два слова.", rule="any", accepted=["acceptance criteria", "критерий приемки", "критерии приемки"]),
    dict(id="sys-02", category="Системный анализ", level="Средний", difficulty="medium", title="UML sequence", prompt="Какая UML-диаграмма показывает сообщения между участниками во времени?", reference="Sequence diagram / диаграмма последовательности", hint="Sequence = последовательность.", rule="any", accepted=["sequence", "диаграмма последовательности"]),
    dict(id="sys-03", category="Системный анализ", level="Средний", difficulty="medium", title="Виды требований", prompt="Назови два больших вида требований к системе.", reference="Функциональные и нефункциональные.", hint="Что система делает и как хорошо она это делает.", rule="all", accepted=["функцион", "нефункцион"]),
    dict(id="sys-04", category="Системный анализ", level="Средний", difficulty="medium", title="Процесс AS-IS", prompt="Что описывает AS-IS модель процесса?", reference="Текущее состояние процесса до изменений.", hint="Противоположность TO-BE.", rule="any", accepted=["текущ", "как есть", "до изменений"]),
    dict(id="sys-05", category="Системный анализ", level="Продвинутый", difficulty="hard", title="BPMN", prompt="Для чего применяют BPMN?", reference="Для моделирования бизнес-процессов.", hint="Процесс, события, задачи, шлюзы.", rule="any", accepted=["бизнес-процесс", "бизнес процесс", "процессов"]),
    # Analytics / product / project
    dict(id="data-01", category="Аналитика", level="Начальный", difficulty="easy", title="AOV", prompt="Средний чек (AOV) равен 3000 ₽. Было 100 заказов. Какая выручка? Введи число.", reference="300000", hint="AOV × число заказов.", rule="numeric", accepted=["300000"]),
    dict(id="data-02", category="Аналитика", level="Средний", difficulty="medium", title="Конверсия", prompt="Что показывает conversion rate?", reference="Долю пользователей, совершивших целевое действие.", hint="Успешные действия / все участники этапа.", rule="all", accepted=["дол", "действ"]),
    dict(id="data-03", category="Аналитика", level="Средний", difficulty="medium", title="Retention", prompt="Что измеряет retention?", reference="Долю пользователей, которые вернулись в продукт за период.", hint="Возвращаемость пользователей.", rule="any", accepted=["вернув", "возвращаем", "вернул"]),
    dict(id="prod-01", category="Product", level="Средний", difficulty="medium", title="MVP", prompt="Что такое MVP?", reference="Минимальный набор функций для проверки ключевой гипотезы.", hint="Не весь продукт, а минимальная проверяемая версия.", rule="all", accepted=["миним", "гипотез"]),
    dict(id="prod-02", category="Product", level="Средний", difficulty="medium", title="Приоритизация", prompt="Назови один метод приоритизации: RICE, ICE, MoSCoW или WSJF.", reference="RICE / ICE / MoSCoW / WSJF", hint="Любой один подход из списка.", rule="any", accepted=["rice", "ice", "moscow", "wsjf"]),
    dict(id="prod-03", category="Product", level="Продвинутый", difficulty="hard", title="Unit economics", prompt="Что такое маржинальный доход в упрощённом виде?", reference="Выручка минус переменные затраты.", hint="Не путай с выручкой.", rule="all", accepted=["выруч", "переменн"]),
    dict(id="proj-01", category="Git и проект", level="Начальный", difficulty="easy", title="Git commit", prompt="Какая команда сохраняет коммит в локальной истории Git?", reference="git commit", hint="Перед ней обычно git add.", rule="all", accepted=["git", "commit"]),
    dict(id="proj-02", category="Git и проект", level="Средний", difficulty="medium", title="README", prompt="Назови минимум две вещи, которые должны быть в хорошем README.", reference="Описание проекта, стек, установка/запуск, скриншоты, архитектура.", hint="Пользователь должен понять, что это и как запустить.", rule="all", accepted=["опис", "запуск"]),
    dict(id="proj-03", category="Git и проект", level="Средний", difficulty="medium", title="Переменные окружения", prompt="Где хранить DATABASE_URL и SECRET_KEY, чтобы не вшивать секреты в код?", reference="Переменные окружения / Secrets.", hint="На хостинге это переменные окружения / Secrets.", rule="any", accepted=["переменн", "secrets", "секрет"]),
]

SQL_CHALLENGES = [
    dict(id="filter-games", title="1. Фильтрация и сортировка", difficulty="Начальный", prompt="Выведи name и price для игр дороже 1000, от самой дорогой к самой дешёвой.", starter="SELECT name, price\nFROM games\nWHERE price > 1000\nORDER BY price DESC;", expected=[("Age of Empires IV", 2999), ("Dragon Quest X", 2499), ("Star Odyssey", 1999), ("Cyber Street", 1799), ("Kingdom Tactics", 1499), ("Farming Days", 1299)]),
    dict(id="join-genres", title="2. JOIN таблиц", difficulty="Средний", prompt="Выведи имя каждой игры и имя её жанра, отсортировав игры по имени.", starter="SELECT g.name, ge.name AS genre\nFROM games g\nJOIN genres ge ON ge.id = g.genre_id\nORDER BY g.name;", expected=[("Age of Empires IV", "Strategy"), ("Cyber Street", "Action"), ("Dragon Quest X", "RPG"), ("Farming Days", "Simulation"), ("Kingdom Tactics", "Strategy"), ("Neon Runner", "Action"), ("Star Odyssey", "RPG"), ("Tiny Farm", "Simulation")]),
    dict(id="genre-count", title="3. GROUP BY", difficulty="Средний", prompt="Посчитай количество игр в каждом жанре. Выведи genre и games_count по названию жанра.", starter="SELECT ge.name AS genre, COUNT(*) AS games_count\nFROM games g JOIN genres ge ON ge.id = g.genre_id\nGROUP BY ge.name\nORDER BY ge.name;", expected=[("Action", 2), ("RPG", 2), ("Simulation", 2), ("Strategy", 2)]),
    dict(id="user-sales", title="4. Агрегация продаж по пользователю", difficulty="Продвинутый", prompt="Посчитай общую сумму покупок для каждого пользователя, у которого есть заказы. Формат: username, total_spent. Сортируй по сумме по убыванию.", starter="SELECT u.username, SUM(oi.quantity * oi.unit_price) AS total_spent\nFROM demo_users u\nJOIN orders o ON o.user_id = u.id\nJOIN order_items oi ON oi.order_id = o.id\nGROUP BY u.username\nORDER BY total_spent DESC;", expected=[("alex", 6296), ("tim", 2999), ("maria", 2499)]),
    dict(id="no-reviews", title="5. LEFT JOIN и отсутствие связей", difficulty="Продвинутый", prompt="Найди названия игр, у которых нет ни одного отзыва. Отсортируй по имени.", starter="SELECT g.name\nFROM games g\nLEFT JOIN reviews r ON r.game_id = g.id\nWHERE r.id IS NULL\nORDER BY g.name;", expected=[("Farming Days",), ("Kingdom Tactics",), ("Tiny Farm",)]),
    dict(id="top-three", title="6. TOP 3", difficulty="Начальный", prompt="Выведи три самые дорогие игры: name, price, сортировка по убыванию цены.", starter="SELECT name, price\nFROM games\nORDER BY price DESC\nLIMIT 3;", expected=[("Age of Empires IV", 2999), ("Dragon Quest X", 2499), ("Star Odyssey", 1999)]),
]

SCHEMA_SQL = """CREATE TABLE genres(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
CREATE TABLE games(id INTEGER PRIMARY KEY, name TEXT NOT NULL, genre_id INTEGER NOT NULL, price INTEGER NOT NULL, release_year INTEGER NOT NULL);
CREATE TABLE demo_users(id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE);
CREATE TABLE orders(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE order_items(id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL, game_id INTEGER NOT NULL, quantity INTEGER NOT NULL, unit_price INTEGER NOT NULL);
CREATE TABLE reviews(id INTEGER PRIMARY KEY, demo_user_id INTEGER NOT NULL, game_id INTEGER NOT NULL, rating INTEGER NOT NULL);"""

def _norm_cell(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return str(v).lower()
    if isinstance(v, (int, float)):
        if float(v).is_integer():
            return str(int(v))
        return str(round(float(v), 6))
    return str(v).strip().lower()

def create_demo_connection():
    con = sqlite3.connect(":memory:")
    con.row_factory = sqlite3.Row
    con.executescript(SCHEMA_SQL)
    con.executemany("INSERT INTO genres VALUES (?,?)", [(1,"RPG"),(2,"Strategy"),(3,"Action"),(4,"Simulation")])
    con.executemany("INSERT INTO games VALUES (?,?,?,?,?)", [
        (1,"Star Odyssey",1,1999,2023),(2,"Kingdom Tactics",2,1499,2022),
        (3,"Neon Runner",3,899,2024),(4,"Farming Days",4,1299,2021),
        (5,"Dragon Quest X",1,2499,2024),(6,"Age of Empires IV",2,2999,2021),
        (7,"Cyber Street",3,1799,2023),(8,"Tiny Farm",4,599,2024)])
    con.executemany("INSERT INTO demo_users VALUES (?,?)", [(1,"alex"),(2,"maria"),(3,"tim"),(4,"zoe")])
    con.executemany("INSERT INTO orders VALUES (?,?,?)", [(1,1,"2026-01-05"),(2,1,"2026-01-08"),(3,2,"2026-01-10"),(4,3,"2026-01-11")])
    con.executemany("INSERT INTO order_items VALUES (?,?,?,?,?)", [(1,1,1,1,1999),(2,1,3,2,899),(3,2,5,1,2499),(4,3,5,1,2499),(5,4,6,1,2999)])
    con.executemany("INSERT INTO reviews VALUES (?,?,?,?)", [(1,1,1,5),(2,2,3,4),(3,3,5,5),(4,1,6,5),(5,3,7,3)])
    return con

def run_sql_safely(query, max_rows=100, timeout_seconds=1.0):
    query = (query or "").strip()
    if not query:
        return {"ok": False, "error": "Введи SQL-запрос.", "columns": [], "rows": [], "correct": False}
    if len(query) > 5000:
        return {"ok": False, "error": "Запрос слишком длинный (максимум 5000 символов).", "columns": [], "rows": [], "correct": False}
    # Strictly require a read-only SELECT or CTE. The SQLite authorizer below is a second guard.
    import re
    if not re.match(r"^(SELECT|WITH)\b", query, re.IGNORECASE):
        return {"ok": False, "error": "Разрешены только SELECT и WITH ... SELECT. Изменять данные нельзя.", "columns": [], "rows": [], "correct": False}
    con = create_demo_connection()
    start = time.monotonic()
    max_steps = 2_000_000
    steps = [0]
    def authorizer(action, arg1, arg2, dbname, source):
        allowed = {sqlite3.SQLITE_SELECT, sqlite3.SQLITE_READ, sqlite3.SQLITE_FUNCTION, getattr(sqlite3, "SQLITE_RECURSIVE", -999)}
        if action == sqlite3.SQLITE_FUNCTION and (arg2 or "").lower() in {"load_extension", "readfile", "writefile"}:
            return sqlite3.SQLITE_DENY
        return sqlite3.SQLITE_OK if action in allowed else sqlite3.SQLITE_DENY
    def progress():
        steps[0] += 1000
        if steps[0] > max_steps or time.monotonic() - start > timeout_seconds:
            return 1
        return 0
    try:
        con.set_authorizer(authorizer)
        con.set_progress_handler(progress, 1000)
        cur = con.execute(query)
        columns = [d[0] for d in (cur.description or [])]
        if not columns:
            return {"ok": False, "error": "Запрос не вернул таблицу результатов.", "columns": [], "rows": [], "correct": False}
        rows = cur.fetchmany(max_rows + 1)
        truncated = len(rows) > max_rows
        rows = rows[:max_rows]
        return {"ok": True, "error": None, "columns": columns, "rows": [[r[i] for i in range(len(columns))] for r in rows], "truncated": truncated, "correct": False}
    except sqlite3.OperationalError as exc:
        msg = str(exc)
        if "not authorized" in msg.lower() or "authorization denied" in msg.lower():
            msg = "Запрос использует запрещённую операцию. Разрешены только чтение данных через SELECT/CTE."
        elif "interrupted" in msg.lower():
            msg = "Запрос превысил лимит выполнения. Попробуй упростить его."
        return {"ok": False, "error": msg, "columns": [], "rows": [], "correct": False}
    except sqlite3.Error as exc:
        return {"ok": False, "error": str(exc), "columns": [], "rows": [], "correct": False}
    finally:
        con.close()

def check_sql_challenge(challenge, result):
    if not result.get("ok"):
        return False
    actual = [tuple(_norm_cell(c) for c in row) for row in result.get("rows", [])]
    expected = [tuple(_norm_cell(c) for c in row) for row in challenge["expected"]]
    return actual == expected
