from __future__ import annotations

import hmac
import json
import os
import re
import secrets
from datetime import date, datetime, timedelta
from functools import wraps
from zoneinfo import ZoneInfo

from flask import (Flask, abort, current_app, flash, g, jsonify, make_response,
                   redirect, render_template, request, session, url_for, send_from_directory)
from sqlalchemy import (Boolean, DateTime, ForeignKey, Integer, String, Text,
                        UniqueConstraint, create_engine, event, func, select)
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker
from werkzeug.security import check_password_hash, generate_password_hash

from curriculum import DAYS, RESOURCES, get_day
from exercises import TASKS, SQL_CHALLENGES, check_sql_challenge, run_sql_safely

MOSCOW = ZoneInfo("Europe/Moscow")


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "academy_users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    xp: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    streak_days: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_active_date: Mapped[str | None] = mapped_column(String(10), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    daily_progress: Mapped[list["DailyProgress"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    solved_tasks: Mapped[list["SolvedTask"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    attempts: Mapped[list["PracticeAttempt"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    sql_attempts: Mapped[list["SQLAttempt"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    projects: Mapped[list["Project"]] = relationship(back_populates="user", cascade="all, delete-orphan")


class DailyProgress(Base):
    __tablename__ = "academy_daily_progress"
    __table_args__ = (UniqueConstraint("user_id", "day_number", name="uq_daily_progress_user_day"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("academy_users.id", ondelete="CASCADE"), index=True)
    day_number: Mapped[int] = mapped_column(Integer)
    completed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    minutes_spent: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    reflection: Mapped[str] = mapped_column(Text, default="", nullable=False)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    xp_awarded: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    user: Mapped[User] = relationship(back_populates="daily_progress")


class PracticeAttempt(Base):
    __tablename__ = "academy_practice_attempts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("academy_users.id", ondelete="CASCADE"), index=True)
    task_id: Mapped[str] = mapped_column(String(80), index=True)
    answer: Mapped[str] = mapped_column(Text, default="")
    correct: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    user: Mapped[User] = relationship(back_populates="attempts")


class SolvedTask(Base):
    __tablename__ = "academy_solved_tasks"
    __table_args__ = (UniqueConstraint("user_id", "task_id", name="uq_solved_user_task"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("academy_users.id", ondelete="CASCADE"), index=True)
    task_id: Mapped[str] = mapped_column(String(100))
    xp_awarded: Mapped[int] = mapped_column(Integer, default=0)
    solved_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    user: Mapped[User] = relationship(back_populates="solved_tasks")


class SQLAttempt(Base):
    __tablename__ = "academy_sql_attempts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("academy_users.id", ondelete="CASCADE"), index=True)
    challenge_id: Mapped[str] = mapped_column(String(100), index=True)
    query_text: Mapped[str] = mapped_column(Text)
    correct: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    user: Mapped[User] = relationship(back_populates="sql_attempts")


class Project(Base):
    __tablename__ = "academy_projects"
    __table_args__ = (UniqueConstraint("user_id", "slug", name="uq_project_user_slug"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("academy_users.id", ondelete="CASCADE"), index=True)
    slug: Mapped[str] = mapped_column(String(80))
    title: Mapped[str] = mapped_column(String(160))
    description: Mapped[str] = mapped_column(Text)
    user: Mapped[User] = relationship(back_populates="projects")
    steps: Mapped[list["ProjectStep"]] = relationship(back_populates="project", cascade="all, delete-orphan", order_by="ProjectStep.step_number")


class ProjectStep(Base):
    __tablename__ = "academy_project_steps"
    __table_args__ = (UniqueConstraint("project_id", "step_number", name="uq_project_step_number"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    project_id: Mapped[int] = mapped_column(ForeignKey("academy_projects.id", ondelete="CASCADE"), index=True)
    step_number: Mapped[int] = mapped_column(Integer)
    title: Mapped[str] = mapped_column(String(220))
    done: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    xp_rewarded: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    project: Mapped[Project] = relationship(back_populates="steps")


PROJECT_SEEDS = [
    ("gamehub", "GameHub 2.0", "Информационная система магазина игр: БД, API, роли и аналитика.", [
        "Сформулировать проблему, роли и MVP", "Нарисовать ER-диаграмму и создать схему БД",
        "Реализовать CRUD и валидацию данных", "Сделать API, авторизацию и контроль ролей",
        "Добавить тесты, README, скриншоты и demo-сценарий"]),
    ("analytics-dashboard", "Analytics Dashboard", "SQL + Python/Excel + BI: от сырых данных до рекомендаций.", [
        "Выбрать набор данных и сформулировать бизнес-вопрос", "Очистить данные и описать ограничения",
        "Подготовить SQL-запросы для метрик", "Построить dashboard с 4–6 KPI",
        "Написать выводы, рекомендации и README"]),
    ("powerlifting-tracker", "Powerlifting Tracker MVP", "Трекер тренировок и прогресса в приседе, жиме и тяге.", [
        "Описать целевых пользователей и проблему", "Спроектировать дневник, упражнения и сессии в БД",
        "Сделать ввод тренировок и историю результатов", "Добавить график прогресса и расчёт оценочного 1RM",
        "Проверить MVP на 3 пользователях и собрать обратную связь"]),
]

COURSES = {
    "sql": {"name": "SQL и базы данных", "icon": "🗄️", "color": "blue"},
    "python": {"name": "Python", "icon": "🐍", "color": "green"},
    "analysis": {"name": "System Analysis и API", "icon": "🧩", "color": "purple"},
    "analytics": {"name": "Data Analytics и BI", "icon": "📊", "color": "cyan"},
    "product": {"name": "Product и бизнес", "icon": "🚀", "color": "orange"},
    "project": {"name": "GameHub и проекты", "icon": "🎮", "color": "pink"},
    "career": {"name": "Портфолио и карьера", "icon": "💼", "color": "yellow"},
}

TASK_BY_ID = {t["id"]: t for t in TASKS}
SQL_CHALLENGE_BY_ID = {t["id"]: t for t in SQL_CHALLENGES}


def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        SECRET_KEY=os.environ.get("SECRET_KEY") or secrets.token_hex(32),
        SECRET_KEY_CONFIGURED=bool(os.environ.get("SECRET_KEY")),
        DATABASE_URL=os.environ.get("DATABASE_URL") or "",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
        MAX_CONTENT_LENGTH=1 * 1024 * 1024,
        PERMANENT_SESSION_LIFETIME=timedelta(days=30),
    )
    if test_config:
        app.config.update(test_config)
    os.makedirs(app.instance_path, exist_ok=True)

    db_url = app.config["DATABASE_URL"]
    if not db_url:
        if os.environ.get("RENDER_REQUIRE_DATABASE") == "1":
            raise RuntimeError("DATABASE_URL is required on Render. Add your Neon PostgreSQL connection string in the Render Environment settings.")
        db_url = "sqlite:///" + os.path.join(app.instance_path, "it_academy.db")
    if db_url.startswith("postgres://"):
        db_url = db_url.replace("postgres://", "postgresql+psycopg://", 1)
    elif db_url.startswith("postgresql://"):
        db_url = db_url.replace("postgresql://", "postgresql+psycopg://", 1)
    engine_kwargs = {"pool_pre_ping": True, "future": True}
    if db_url.startswith("sqlite://"):
        engine_kwargs["connect_args"] = {"check_same_thread": False, "timeout": 15}
        if db_url in {"sqlite://", "sqlite:///:memory:"}:
            from sqlalchemy.pool import StaticPool
            engine_kwargs["poolclass"] = StaticPool
    engine = create_engine(db_url, **engine_kwargs)
    if engine.dialect.name == "sqlite":
        @event.listens_for(engine, "connect")
        def sqlite_foreign_keys(dbapi_connection, _connection_record):
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()
    Base.metadata.create_all(engine)
    app.extensions["academy_engine"] = engine
    app.extensions["academy_sessionmaker"] = sessionmaker(bind=engine, expire_on_commit=False)
    app.extensions["database_kind"] = engine.dialect.name

    @app.before_request
    def open_db_and_check_csrf():
        g.db = app.extensions["academy_sessionmaker"]()
        if request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            sent = request.form.get("csrf_token", "")
            expected = session.get("_csrf_token", "")
            if not sent or not expected or not hmac.compare_digest(sent, expected):
                abort(400, description="Форма устарела или CSRF-токен отсутствует. Обнови страницу и попробуй снова.")

    @app.teardown_request
    def close_db(_error=None):
        db = g.pop("db", None)
        if db is not None:
            if _error:
                db.rollback()
            db.close()

    @app.after_request
    def security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        # Dynamic pages include user-specific data and should not be cached by shared browsers.
        if request.endpoint not in {"static", "service_worker", "manifest"}:
            response.headers["Cache-Control"] = "no-store"
        return response

    def csrf_token():
        if "_csrf_token" not in session:
            session["_csrf_token"] = secrets.token_urlsafe(32)
        return session["_csrf_token"]

    def current_user():
        uid = session.get("user_id")
        return g.db.get(User, uid) if uid else None

    def login_required(fn):
        @wraps(fn)
        def wrapped(*args, **kwargs):
            if not current_user():
                flash("Сначала войди в аккаунт — так прогресс будет привязан к тебе.", "info")
                return redirect(url_for("login", next=request.path))
            return fn(*args, **kwargs)
        return wrapped

    def add_xp(user: User, amount: int):
        user.xp += amount

    def record_activity(user: User):
        today = datetime.now(MOSCOW).date()
        today_s = today.isoformat()
        if user.last_active_date == today_s:
            return
        if user.last_active_date:
            try:
                previous = date.fromisoformat(user.last_active_date)
                user.streak_days = user.streak_days + 1 if previous == today - timedelta(days=1) else 1
            except ValueError:
                user.streak_days = 1
        else:
            user.streak_days = 1
        user.last_active_date = today_s

    def get_user_projects(user: User):
        if not user.projects:
            for slug, title, description, steps in PROJECT_SEEDS:
                project = Project(slug=slug, title=title, description=description)
                project.steps = [ProjectStep(step_number=i, title=step) for i, step in enumerate(steps, start=1)]
                user.projects.append(project)
            g.db.flush()
        return sorted(user.projects, key=lambda x: x.id)

    def award_solved_once(user: User, task_id: str, amount: int) -> bool:
        existing = g.db.scalar(select(SolvedTask).where(SolvedTask.user_id == user.id, SolvedTask.task_id == task_id))
        if existing:
            return False
        g.db.add(SolvedTask(user_id=user.id, task_id=task_id, xp_awarded=amount))
        add_xp(user, amount)
        record_activity(user)
        return True

    def normalise_answer(s: str) -> str:
        return " ".join((s or "").lower().replace("ё", "е").strip().split())

    def grade_task(task: dict, answer: str) -> bool:
        a = normalise_answer(answer)
        rule = task["rule"]
        accepted = [normalise_answer(x) for x in task["accepted"]]
        if rule == "exact_any":
            return a in accepted
        if rule == "contains":
            return any(x in a for x in accepted)
        if rule == "all":
            return all(x in a for x in accepted)
        if rule == "any":
            return any(x in a for x in accepted)
        if rule == "numeric":
            return re.sub(r"[\s₽,._]", "", a) in [re.sub(r"[\s₽,._]", "", x) for x in accepted]
        return False

    def achievement_list(user: User):
        solved_ids = {s.task_id for s in user.solved_tasks}
        completed_days = {p.day_number for p in user.daily_progress if p.completed}
        sql_done = sum(1 for x in SQL_CHALLENGES if f"sql-lab:{x['id']}" in solved_ids)
        finished_projects = 0
        for p in user.projects:
            if p.steps and all(step.done for step in p.steps):
                finished_projects += 1
        return [
            ("🎯", "Первый ответ", "Реши первое задание", len(solved_ids) >= 1),
            ("⭐", "500 XP", "Набери 500 XP", user.xp >= 500),
            ("🗄️", "SQL Lab", "Реши 3 задачи в SQL-тренажёре", sql_done >= 3),
            ("🔥", "Серия 7 дней", "Занимайся 7 разных дней подряд", user.streak_days >= 7),
            ("📅", "30 дней", "Заверши 30 учебных дней", len(completed_days) >= 30),
            ("🏆", "90 дней", "Заверши всю программу", len(completed_days) >= 90),
            ("🧱", "Первый проект", "Заверши все шаги одного проекта", finished_projects >= 1),
        ]

    @app.context_processor
    def inject_globals():
        u = current_user()
        return {
            "me": u,
            "csrf_token": csrf_token,
            "level": (u.xp // 500 + 1) if u else 1,
            "courses": COURSES,
            "database_kind": app.extensions["database_kind"],
            "persistent_db": app.extensions["database_kind"] == "postgresql",
            "today_string": datetime.now(MOSCOW).date().isoformat(),
        }

    @app.route("/")
    @login_required
    def home():
        user = current_user()
        done = {p.day_number for p in user.daily_progress if p.completed}
        next_day = next((n for n in range(1, 91) if n not in done), 90)
        daily = get_day(next_day)
        solved = len({t.task_id for t in user.solved_tasks})
        project_rows = get_user_projects(user)
        g.db.commit()
        course_stats = []
        for key, meta in COURSES.items():
            day_numbers = [d["day"] for d in DAYS if d["category"] == key]
            completed_count = sum(1 for n in day_numbers if n in done)
            if day_numbers:
                course_stats.append({"key": key, "meta": meta, "done": completed_count, "total": len(day_numbers), "pct": round(completed_count / len(day_numbers) * 100)})
        recent = g.db.scalars(select(PracticeAttempt).where(PracticeAttempt.user_id == user.id).order_by(PracticeAttempt.created_at.desc()).limit(5)).all()
        return render_template("index.html", user=user, days_done=len(done), done_days=done, next_day=next_day, daily=daily,
                               solved_count=solved, total_tasks=len(TASKS) + len(SQL_CHALLENGES), projects=project_rows,
                               achievements=achievement_list(user), course_stats=course_stats, recent=recent)

    @app.route("/roadmap")
    @login_required
    def roadmap():
        user = current_user()
        done_days = {p.day_number for p in user.daily_progress if p.completed}
        next_uncompleted = next((n for n in range(1, 91) if n not in done_days), 90)
        return render_template("roadmap.html", days=DAYS, done_days=done_days, next_uncompleted=next_uncompleted)

    @app.route("/day/<int:day_number>")
    @login_required
    def day_page(day_number: int):
        item = get_day(day_number)
        if not item:
            abort(404)
        user = current_user()
        progress = g.db.scalar(select(DailyProgress).where(DailyProgress.user_id == user.id, DailyProgress.day_number == day_number))
        done_days = {p.day_number for p in user.daily_progress if p.completed}
        return render_template("day.html", item=item, progress=progress, done_days=done_days)

    @app.post("/day/<int:day_number>/complete")
    @login_required
    def complete_day(day_number: int):
        item = get_day(day_number)
        if not item:
            abort(404)
        user = current_user()
        progress = g.db.scalar(select(DailyProgress).where(DailyProgress.user_id == user.id, DailyProgress.day_number == day_number))
        minutes_raw = request.form.get("minutes_spent", "0")
        try:
            minutes = max(0, min(600, int(minutes_raw)))
        except ValueError:
            minutes = 0
        reflection = request.form.get("reflection", "").strip()[:3000]
        if progress is None:
            progress = DailyProgress(user_id=user.id, day_number=day_number)
            g.db.add(progress)
        newly_completed = not progress.completed
        progress.completed = True
        progress.minutes_spent = minutes
        progress.reflection = reflection
        progress.completed_at = datetime.utcnow()
        if newly_completed and not progress.xp_awarded:
            progress.xp_awarded = True
            add_xp(user, 100)
        record_activity(user)
        g.db.commit()
        flash("Учебный день сохранён. +100 XP начисляются только один раз за день." if newly_completed else "Заметки обновлены; повторного начисления XP нет.", "success")
        return redirect(url_for("day_page", day_number=day_number))

    @app.route("/practice")
    @login_required
    def practice():
        user = current_user()
        solved = {s.task_id for s in user.solved_tasks}
        category = request.args.get("category", "all")
        categories = sorted({t["category"] for t in TASKS})
        filtered = [t for t in TASKS if category == "all" or t["category"] == category]
        return render_template("practice.html", tasks=filtered, solved=solved, categories=categories, selected_category=category)

    @app.post("/practice/submit")
    @login_required
    def practice_submit():
        user = current_user()
        task_id = request.form.get("task_id", "")
        answer = request.form.get("answer", "").strip()[:5000]
        task = next((x for x in TASKS if x["id"] == task_id), None)
        if task is None:
            abort(404)
        correct = grade_task(task, answer)
        g.db.add(PracticeAttempt(user_id=user.id, task_id=task_id, answer=answer, correct=correct))
        xp = {"easy": 25, "medium": 40, "hard": 60}[task["difficulty"]]
        gained = award_solved_once(user, task_id, xp) if correct else False
        record_activity(user)
        g.db.commit()
        if correct:
            flash(f"Верно! {'+' + str(xp) + ' XP.' if gained else 'Задача уже была решена — повторный XP не начислен.'}", "success")
        else:
            flash("Пока не засчитано. Посмотри подсказку и попробуй ещё раз. Автопроверка оценивает ключевые признаки ответа.", "warning")
        return redirect(url_for("practice", category=request.form.get("return_category", "all")) + f"#task-{task_id}")

    @app.route("/sql-lab", methods=["GET", "POST"])
    @login_required
    def sql_lab():
        user = current_user()
        selected_id = request.values.get("challenge", SQL_CHALLENGES[0]["id"])
        challenge = SQL_CHALLENGE_BY_ID.get(selected_id) or SQL_CHALLENGES[0]
        query_text = challenge["starter"]
        result = None
        gained = False
        if request.method == "POST":
            query_text = request.form.get("query", "")[:5000]
            result = run_sql_safely(query_text)
            if result.get("ok"):
                result["correct"] = check_sql_challenge(challenge, result)
            g.db.add(SQLAttempt(user_id=user.id, challenge_id=challenge["id"], query_text=query_text, correct=bool(result.get("correct"))))
            if result.get("correct"):
                gained = award_solved_once(user, f"sql-lab:{challenge['id']}", 50)
                if gained:
                    flash("Задача решена на демо-данных! +50 XP. Повторно XP за эту задачу не начисляется.", "success")
                else:
                    flash("Результат правильный! Эта SQL-задача уже зачтена ранее.", "success")
            elif result.get("ok"):
                flash("Запрос выполнился, но набор строк не совпал с целевым результатом. Сравни данные и сортировку.", "warning")
            else:
                flash("SQL не выполнен. Проверь синтаксис и используй только SELECT/WITH.", "warning")
            record_activity(user)
            g.db.commit()
        solved = {s.task_id.removeprefix("sql-lab:") for s in user.solved_tasks if s.task_id.startswith("sql-lab:")}
        return render_template("sql_lab.html", challenges=SQL_CHALLENGES, challenge=challenge, query_text=query_text, result=result, solved=solved)

    @app.route("/projects")
    @login_required
    def projects():
        user = current_user()
        rows = get_user_projects(user)
        g.db.commit()
        return render_template("projects.html", projects=rows)

    @app.route("/projects/<slug>")
    @login_required
    def project_detail(slug: str):
        user = current_user()
        project = g.db.scalar(select(Project).where(Project.user_id == user.id, Project.slug == slug))
        if project is None:
            abort(404)
        return render_template("project_detail.html", project=project)

    @app.post("/projects/<slug>/steps/<int:step_id>/toggle")
    @login_required
    def toggle_project_step(slug: str, step_id: int):
        user = current_user()
        step = g.db.scalar(select(ProjectStep).join(Project).where(Project.user_id == user.id, Project.slug == slug, ProjectStep.id == step_id))
        if step is None:
            abort(404)
        step.done = not step.done
        if step.done and not step.xp_rewarded:
            step.xp_rewarded = True
            add_xp(user, 15)
            record_activity(user)
            flash("Шаг проекта отмечен. +15 XP.", "success")
        else:
            flash("Состояние шага обновлено. Повторного начисления XP нет.", "info")
        g.db.commit()
        return redirect(url_for("project_detail", slug=slug))

    @app.route("/stats")
    @login_required
    def stats():
        user = current_user()
        completed = {p.day_number for p in user.daily_progress if p.completed}
        all_attempts = len(user.attempts)
        correct_attempts = sum(1 for a in user.attempts if a.correct)
        minutes = sum(p.minutes_spent for p in user.daily_progress if p.completed)
        total_steps = sum(len(p.steps) for p in user.projects)
        done_steps = sum(1 for p in user.projects for step in p.steps if step.done)
        activity_days = len({p.completed_at.date() for p in user.daily_progress if p.completed and p.completed_at})
        return render_template("stats.html", user=user, completed=completed, achievements=achievement_list(user),
                               all_attempts=all_attempts, correct_attempts=correct_attempts,
                               minutes=minutes, total_steps=total_steps, done_steps=done_steps, activity_days=activity_days)

    @app.route("/settings", methods=["GET", "POST"])
    @login_required
    def settings():
        user = current_user()
        if request.method == "POST":
            old_password = request.form.get("old_password", "")
            new_password = request.form.get("new_password", "")
            confirm = request.form.get("confirm_password", "")
            if not check_password_hash(user.password_hash, old_password):
                flash("Текущий пароль не совпал.", "error")
            elif len(new_password) < 10:
                flash("Новый пароль должен содержать минимум 10 символов.", "warning")
            elif new_password != confirm:
                flash("Новые пароли не совпадают.", "warning")
            else:
                user.password_hash = generate_password_hash(new_password, method="scrypt")
                g.db.commit()
                flash("Пароль обновлён.", "success")
        return render_template("settings.html")

    @app.route("/export")
    @login_required
    def export_data():
        user = current_user()
        payload = {
            "username": user.username,
            "exported_at_utc": datetime.utcnow().isoformat() + "Z",
            "xp": user.xp,
            "streak_days": user.streak_days,
            "completed_days": [{"day": p.day_number, "completed_at": p.completed_at.isoformat() if p.completed_at else None,
                                "minutes_spent": p.minutes_spent, "reflection": p.reflection} for p in user.daily_progress if p.completed],
            "solved_tasks": [{"task_id": s.task_id, "xp_awarded": s.xp_awarded, "solved_at": s.solved_at.isoformat()} for s in user.solved_tasks],
            "projects": [{"slug": p.slug, "title": p.title, "steps": [{"title": st.title, "done": st.done} for st in p.steps]} for p in user.projects],
        }
        response = make_response(json.dumps(payload, ensure_ascii=False, indent=2))
        response.headers["Content-Type"] = "application/json; charset=utf-8"
        response.headers["Content-Disposition"] = "attachment; filename=it-academy-progress.json"
        return response

    @app.route("/api/state")
    @login_required
    def api_state():
        user = current_user()
        done = sorted(p.day_number for p in user.daily_progress if p.completed)
        solved = sorted(s.task_id for s in user.solved_tasks)
        return jsonify({"username": user.username, "xp": user.xp, "level": user.xp // 500 + 1,
                        "streak_days": user.streak_days, "completed_days": done, "solved_tasks": solved,
                        "database": app.extensions["database_kind"]})

    @app.route("/guide")
    def setup_guide():
        return render_template("guide.html")

    @app.route("/guide/download")
    def download_guide():
        return send_from_directory(app.root_path, "DEPLOY_GUIDE_RU.md", as_attachment=True, download_name="IT_Academy_Инструкция_Render.md")

    @app.route("/healthz")
    def healthz():
        try:
            g.db.execute(select(1))
            return jsonify({"status": "ok", "database": app.extensions["database_kind"]}), 200
        except SQLAlchemyError:
            return jsonify({"status": "error", "database": "unavailable"}), 503

    @app.route("/manifest.json")
    def manifest():
        return current_app.send_static_file("manifest.json")

    @app.route("/service-worker.js")
    def service_worker():
        response = current_app.send_static_file("service-worker.js")
        response.headers["Service-Worker-Allowed"] = "/"
        response.headers["Cache-Control"] = "no-cache"
        return response

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if current_user():
            return redirect(url_for("home"))
        if request.method == "POST":
            username = request.form.get("username", "").strip().lower()
            password = request.form.get("password", "")
            user = g.db.scalar(select(User).where(User.username == username))
            if user and check_password_hash(user.password_hash, password):
                session.clear()
                session["user_id"] = user.id
                session.permanent = True
                flash("Вход выполнен. Продолжай обучение!", "success")
                next_path = request.args.get("next", "")
                if next_path.startswith("/") and not next_path.startswith("//"):
                    return redirect(next_path)
                return redirect(url_for("home"))
            flash("Логин или пароль неверны.", "error")
        return render_template("auth.html", mode="login")

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if current_user():
            return redirect(url_for("home"))
        if request.method == "POST":
            username = request.form.get("username", "").strip().lower()
            password = request.form.get("password", "")
            confirm = request.form.get("confirm_password", "")
            if not re.fullmatch(r"[a-z0-9_.-]{3,32}", username):
                flash("Логин: 3–32 символа, английские буквы, цифры, точка, дефис или подчёркивание.", "warning")
            elif len(password) < 10:
                flash("Пароль должен содержать минимум 10 символов.", "warning")
            elif password != confirm:
                flash("Пароли не совпадают.", "warning")
            else:
                user = User(username=username, password_hash=generate_password_hash(password, method="scrypt"))
                try:
                    g.db.add(user)
                    g.db.flush()
                    for slug, title, description, steps in PROJECT_SEEDS:
                        project = Project(user_id=user.id, slug=slug, title=title, description=description)
                        project.steps = [ProjectStep(step_number=i, title=step) for i, step in enumerate(steps, start=1)]
                        g.db.add(project)
                    g.db.commit()
                    session.clear()
                    session["user_id"] = user.id
                    session.permanent = True
                    flash("Аккаунт создан. Добро пожаловать в IT Academy!", "success")
                    return redirect(url_for("home"))
                except IntegrityError:
                    g.db.rollback()
                    flash("Этот логин уже занят. Выбери другой.", "warning")
        return render_template("auth.html", mode="register")

    @app.route("/logout", methods=["POST"])
    @login_required
    def logout():
        session.clear()
        flash("Ты вышел из аккаунта.", "info")
        return redirect(url_for("login"))

    @app.errorhandler(400)
    def bad_request(error):
        return render_template("error.html", code=400, title="Форма устарела", message=getattr(error, "description", "Обнови страницу и повтори действие.")), 400

    @app.errorhandler(404)
    def not_found(_error):
        return render_template("error.html", code=404, title="Страница не найдена", message="Проверь адрес или вернись на dashboard."), 404

    @app.errorhandler(500)
    def server_error(_error):
        return render_template("error.html", code=500, title="Внутренняя ошибка", message="Обнови страницу. Если ошибка повторяется, проверь Logs в Render."), 500

    return app


app = create_app()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False)
