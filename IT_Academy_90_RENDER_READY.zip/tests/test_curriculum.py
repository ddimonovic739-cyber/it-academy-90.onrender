from curriculum import DAYS, get_day


def test_curriculum_has_exactly_90_unique_days():
    assert len(DAYS) == 90
    assert [item["day"] for item in DAYS] == list(range(1, 91))
    assert len({item["title"] for item in DAYS}) == 90
    assert all(item["task"] and item["deliverable"] and item["resources"] for item in DAYS)


def test_day_boundaries():
    assert get_day(1)["week"] == 1
    assert get_day(90)["day"] == 90
    assert get_day(0) is None
    assert get_day(91) is None
