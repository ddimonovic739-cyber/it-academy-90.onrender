import re
import pytest
from app import create_app


@pytest.fixture()
def client():
    app = create_app({
        "TESTING": True,
        "SECRET_KEY": "test-secret-key-for-tests-only",
        "SECRET_KEY_CONFIGURED": True,
        "DATABASE_URL": "sqlite:///:memory:",
        "SESSION_COOKIE_SECURE": False,
    })
    with app.test_client() as client:
        yield client
    app.extensions["academy_engine"].dispose()


def csrf(response):
    match = re.search(r'name="csrf_token" value="([^"]+)"', response.get_data(as_text=True))
    assert match, "CSRF token not found in rendered form"
    return match.group(1)


def register(client, username="tester"):
    page = client.get("/register")
    return client.post("/register", data={
        "csrf_token": csrf(page),
        "username": username,
        "password": "long-test-password-123",
        "confirm_password": "long-test-password-123",
    }, follow_redirects=True)


def test_registration_and_dashboard(client):
    response = register(client)
    assert response.status_code == 200
    assert "IT Academy" in response.get_data(as_text=True)
    assert client.get("/api/state").get_json()["username"] == "tester"


def test_day_xp_is_idempotent_and_persisted(client):
    register(client)
    page = client.get("/day/1")
    token = csrf(page)
    first = client.post("/day/1/complete", data={"csrf_token": token, "minutes_spent": "60", "reflection": "SQL intro"}, follow_redirects=True)
    assert first.status_code == 200
    state = client.get("/api/state").get_json()
    assert state["xp"] == 100
    assert state["completed_days"] == [1]
    page = client.get("/day/1")
    client.post("/day/1/complete", data={"csrf_token": csrf(page), "minutes_spent": "75", "reflection": "Updated notes"}, follow_redirects=True)
    assert client.get("/api/state").get_json()["xp"] == 100


def test_practice_xp_cannot_be_farmed(client):
    register(client)
    page = client.get("/practice")
    token = csrf(page)
    for _ in range(2):
        client.post("/practice/submit", data={"csrf_token": token, "task_id": "py-01", "answer": "6", "return_category": "all"}, follow_redirects=True)
    state = client.get("/api/state").get_json()
    assert state["xp"] == 25
    assert "py-01" in state["solved_tasks"]


def test_sql_lab_awards_once(client):
    register(client)
    page = client.get("/sql-lab")
    token = csrf(page)
    starter = "SELECT name, price FROM games WHERE price > 1000 ORDER BY price DESC;"
    for _ in range(2):
        response = client.post("/sql-lab", data={"csrf_token": token, "challenge": "filter-games", "query": starter}, follow_redirects=True)
        assert response.status_code == 200
        token = csrf(response)
    state = client.get("/api/state").get_json()
    assert state["xp"] == 50
    assert "sql-lab:filter-games" in state["solved_tasks"]


def test_user_cannot_read_other_users_progress(client):
    register(client, "firstuser")
    first_state = client.get("/api/state").get_json()
    assert first_state["username"] == "firstuser"
    client.post("/logout", data={"csrf_token": csrf(client.get("/"))}, follow_redirects=True)
    register(client, "seconduser")
    state = client.get("/api/state").get_json()
    assert state["username"] == "seconduser"
    assert state["xp"] == 0
    assert state["completed_days"] == []
