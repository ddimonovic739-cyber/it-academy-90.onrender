from exercises import SQL_CHALLENGES, check_sql_challenge, run_sql_safely


def test_all_starter_queries_match_expected_output():
    for challenge in SQL_CHALLENGES:
        result = run_sql_safely(challenge["starter"])
        assert result["ok"], (challenge["id"], result.get("error"))
        assert check_sql_challenge(challenge, result), challenge["id"]


def test_write_operations_are_denied():
    for query in ["DROP TABLE games", "DELETE FROM games", "UPDATE games SET price=0", "INSERT INTO games VALUES (99,'x',1,1,2024)"]:
        result = run_sql_safely(query)
        assert not result["ok"]


def test_multi_statement_and_empty_queries_are_rejected():
    assert not run_sql_safely("")["ok"]
    multi = run_sql_safely("SELECT name FROM games; SELECT name FROM games;")
    assert not multi["ok"]


def test_with_select_is_allowed():
    result = run_sql_safely("WITH totals AS (SELECT COUNT(*) AS n FROM games) SELECT n FROM totals")
    assert result["ok"]
    assert result["rows"] == [[8]]
